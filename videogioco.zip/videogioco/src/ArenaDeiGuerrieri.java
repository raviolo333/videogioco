
// Classe principale Arena
public class ArenaDeiGuerrieri {
    public static void main(String[] args) {
        System.out.println("Benvenuti nell'Arena dei Guerrieri!");
        System.out.println("In un regno lontano, dove l'onore si misura con la lama e la magia domina i cieli,");
        System.out.println("gli eroi più valorosi si radunano per combattere nella leggendaria Arena dei Guerrieri.");
        System.out.println("Questa è una terra dove solo il più forte, il più astuto, o il più coraggioso può prevalere.");
        System.out.println("Siete pronti a entrare in questo epico scontro e a determinare il destino dei combattenti?");
        System.out.println();

        Combattimento combattimento = new Combattimento();
        combattimento.inizia();
    }
}
