import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

class Combattimento {
    public void inizia() {
        Scanner scanner = new Scanner(System.in);
        List<Guerriero> guerrieri = new ArrayList<>();

        // Creazione dei guerrieri con nomi di fantasia
        guerrieri.add(new Cavaliere("Sir Pollins"));
        guerrieri.add(new Mago("Bettys il Saggio"));
        guerrieri.add(new Arciere("Alexius l'Implacabile"));

        System.out.println("Benvenuti nell'Arena dei Guerrieri!");
        System.out.println("Nella lontana terra di Avalon, ogni anno, di fronte a Oberon e Titania, re e regina delle fate, si tiene il Grande Torneo, un evento epico in cui guerrieri di ogni angolo del mondo si sfidano nell’arena. Il vincitore guadagna l’onore eterno e una leggendaria reliquia magica, la \"Lama degli Eterni\". Tra i partecipanti ci sono cavalieri valorosi, maghi potenti e abili arcieri, ognuno con abilità e strategie uniche. Ma nell’arena non ci sono amici: solo l’ultimo guerriero rimasto potrà essere proclamato campione.");

        boolean continuaGioco = true;
        while (continuaGioco) {
            // Scelta del guerriero da parte dell'utente
            System.out.println("\nScegli il tuo guerriero:");
            for (int i = 0; i < guerrieri.size(); i++) {
                System.out.println((i + 1) + ". " + guerrieri.get(i).getNome());
            }
            int sceltaUtente = scanner.nextInt() - 1;
            Guerriero guerrieroUtente = guerrieri.get(sceltaUtente);

            // Scelta del nemico
            System.out.println("\nScegli chi combattere:");
            for (int i = 0; i < guerrieri.size(); i++) {
                if (i != sceltaUtente) {
                    System.out.println((i + 1) + ". " + guerrieri.get(i).getNome());
                }
            }
            int sceltaNemico;
            do {
                sceltaNemico = scanner.nextInt() - 1;
                if (sceltaNemico == sceltaUtente) {
                    System.out.println("Non puoi scegliere te stesso come nemico! Riprova.");
                }
            } while (sceltaNemico == sceltaUtente);
            Guerriero guerrieroNemico = guerrieri.get(sceltaNemico);

            System.out.println("\nHai scelto: " + guerrieroUtente.getNome() + ". Il tuo avversario è: " + guerrieroNemico.getNome());
            Random random = new Random();

            // Combattimento 1 contro 1
            while (guerrieroUtente.isAlive() && guerrieroNemico.isAlive()) {
                System.out.println("\nInizia un nuovo turno!");

                // Turno dell'utente
                System.out.println("È il tuo turno! Scegli la tua mossa:");
                List<String> mosse = guerrieroUtente.getMosse();
                for (int i = 0; i < mosse.size(); i++) {
                    System.out.println((i + 1) + ". " + mosse.get(i));
                }
                int sceltaMossa = scanner.nextInt() - 1;
                guerrieroUtente.eseguiMossa(sceltaMossa, guerrieroNemico);
                guerrieroUtente.consumoEnergia(10); // Ogni mossa consuma energia
                guerrieroNemico.mostraStato();

                // Controllo se il nemico è stato sconfitto
                if (!guerrieroNemico.isAlive()) {
                    break;
                }

                // Turno del nemico
                System.out.println("È il turno del nemico!");
                int mossaCasuale = random.nextInt(guerrieroNemico.getMosse().size());
                guerrieroNemico.eseguiMossa(mossaCasuale, guerrieroUtente);
                guerrieroNemico.consumoEnergia(10); // Ogni mossa consuma energia
                guerrieroUtente.mostraStato();
            }

            // Dichiarazione del vincitore
            if (guerrieroUtente.isAlive()) {
                System.out.println("\nHai vinto! " + guerrieroUtente.getNome() + " è il trionfatore!");
                System.out.println("La folla esulta mentre " + guerrieroUtente.getNome() + " solleva la \"Lama degli Eterni\" al cielo, consacrato come il nuovo campione dell'arena. Oberon e Titania, impressionati dal tuo coraggio, ti benedicono con un incantesimo di eterna gloria.");

                // Scelta del premio
                System.out.println("Scegli il tuo premio:");
                System.out.println("1 - Cimiero d'Onore (aumenta la resistenza del guerriero)");
                System.out.println("2 - Ali della Vittoria (migliora velocità e agilità)");
                System.out.println("3 - Stella Eterna (conferisce energia magica aggiuntiva)");

                int scelta = scanner.nextInt();
                switch (scelta) {
                    case 1:
                        guerrieroUtente.aumentaResistenza();
                        System.out.println("Hai scelto il Cimiero d'Onore! Ora sei più resistente agli attacchi.");
                        break;
                    case 2:
                        guerrieroUtente.aumentaVelocita();
                        System.out.println("Hai scelto le Ali della Vittoria! Ora ti muovi più rapidamente in combattimento.");
                        break;
                    case 3:
                        guerrieroUtente.aumentaEnergiaMagica();
                        System.out.println("Hai scelto la Stella Eterna! Il tuo potere magico si è intensificato.");
                        break;
                    default:
                        System.out.println("Scelta non valida, nessun premio assegnato.");
                }

                // Chiedere se il giocatore vuole combattere di nuovo
                System.out.println("Vuoi fare un'altra battaglia? (sì/no)");
                String risposta = scanner.next();
                if (!risposta.equalsIgnoreCase("sì")) {
                    continuaGioco = false;
                }
            } else {
                System.out.println("\nSei stato sconfitto. " + guerrieroNemico.getNome() + " è il vincitore.");
                System.out.println("Mentre cadi sull'arena, l'eco degli applausi per " + guerrieroNemico.getNome() + " riempie l'aria. Oberon e Titania abbassano lo sguardo, e la \"Lama degli Eterni\" passa nelle mani del tuo avversario, lasciandoti solo con il ricordo della tua lotta epica.");
                continuaGioco = false;
            }
        }
        scanner.close();
    }
}