import java.util.List;
import java.util.ArrayList;

abstract class Guerriero {
    protected String nome;
    protected int salute;
    protected int energia;
    protected int danno;

    public Guerriero(String nome, int salute, int energia, int danno) {
        this.nome = nome;
        this.salute = salute;
        this.energia = energia;
        this.danno = danno;
    }

    public String getNome() {
        return nome;
    }

    public boolean isAlive() {
        return salute > 0;
    }

    public void subisciDanno(int danno) {
        salute -= danno;
        if (salute < 0) {
            salute = 0;
        }
    }

    public void consumoEnergia(int costo) {
        energia -= costo;
        if (energia < 0) {
            energia = 0;
        }
    }

    public void recuperaEnergia(int recupero) {
        energia += recupero;
        if (energia > 100) { // Limite massimo per l'energia
            energia = 100;
        }
    }

    public void mostraStato() {
        System.out.println(nome + " - Salute: " + salute + " - Energia: " + energia);
    }

    public void aumentaResistenza() {
        salute += 20; // Aumenta la salute del guerriero
        System.out.println(nome + " ha aumentato la sua resistenza! Salute: " + salute);
    }

    public void aumentaVelocita() {
        energia += 20; // Aumenta l'energia del guerriero
        System.out.println(nome + " ha aumentato la sua velocità! Energia: " + energia);
    }

    public void aumentaEnergiaMagica() {
        danno += 5; // Aumenta il danno del guerriero
        System.out.println(nome + " ha aumentato il suo potere magico! Danno: " + danno);
    }

    public abstract List<String> getMosse();

    public abstract void eseguiMossa(int scelta, Guerriero avversario);
}

class Cavaliere extends Guerriero {
    public Cavaliere(String nome) {
        super(nome, 100, 100, 15);
    }

    @Override
    public List<String> getMosse() {
        List<String> mosse = new ArrayList<>();
        mosse.add("Attacco con la spada - Un colpo deciso che infligge danni standard al nemico.");
        mosse.add("Parata difensiva - Il cavaliere alza il suo scudo, recuperando una piccola parte di salute e riducendo i danni nel prossimo turno.");
        mosse.add("Carica potente - Una mossa audace che infligge il doppio dei danni, ma richiede grande energia.");
        mosse.add("Riposo - Recupera energia per il prossimo turno.");
        return mosse;
    }

    @Override
    public void eseguiMossa(int scelta, Guerriero avversario) {
        switch (scelta) {
            case 0:
                System.out.println(nome + " colpisce con la spada " + avversario.getNome());
                avversario.subisciDanno(danno);
                break;
            case 1:
                System.out.println(nome + " si difende, recuperando energia e preparandosi a resistere.");
                salute += 10; // Recupera salute
                consumoEnergia(5); // Costa meno energia
                break;
            case 2:
                System.out.println(nome + " carica con furia contro " + avversario.getNome() + ", infliggendo un colpo devastante!");
                avversario.subisciDanno(danno * 2);
                consumoEnergia(20); // Costa più energia
                break;
            case 3:
                System.out.println(nome + " si riposa, recuperando energia.");
                recuperaEnergia(20);
                break;
            default:
                System.out.println("Mossa non valida!");
        }
    }
}

class Mago extends Guerriero {
    public Mago(String nome) {
        super(nome, 80, 100, 20);
    }

    @Override
    public List<String> getMosse() {
        List<String> mosse = new ArrayList<>();
        mosse.add("Palla di fuoco - Un incantesimo ardente che infligge danni diretti al nemico.");
        mosse.add("Scudo magico - Una protezione mistica che aumenta temporaneamente la salute del mago.");
        mosse.add("Fulmine - Un lampo abbagliante che infligge danni potenziati al nemico.");
        mosse.add("Meditazione - Recupera energia per il prossimo turno.");
        return mosse;
    }

    @Override
    public void eseguiMossa(int scelta, Guerriero avversario) {
        switch (scelta) {
            case 0:
                System.out.println(nome + " lancia una palla di fuoco contro " + avversario.getNome() + ", avvolgendolo nelle fiamme!");
                avversario.subisciDanno(danno);
                consumoEnergia(15);
                break;
            case 1:
                System.out.println(nome + " evoca uno scudo magico, avvolto in un bagliore protettivo.");
                salute += 15; // Aumenta salute
                consumoEnergia(10);
                break;
            case 2:
                System.out.println(nome + " invoca un fulmine che colpisce con potenza " + avversario.getNome() + "!");
                avversario.subisciDanno(danno * 3 / 2);
                consumoEnergia(20);
                break;
            case 3:
                System.out.println(nome + " medita per recuperare energia.");
                recuperaEnergia(25);
                break;
            default:
                System.out.println("Mossa non valida!");
        }
    }
}

class Arciere extends Guerriero {
    public Arciere(String nome) {
        super(nome, 90, 100, 10);
    }

    @Override
    public List<String> getMosse() {
        List<String> mosse = new ArrayList<>();
        mosse.add("Freccia veloce - Una freccia rapida che colpisce il bersaglio infliggendo danni standard.");
        mosse.add("Freccia avvelenata - Una freccia letale che infligge danni continui grazie al veleno.");
        mosse.add("Colpo mirato - Un tiro preciso che infligge il doppio dei danni al nemico.");
        mosse.add("Recupero - Recupera energia per il prossimo turno.");
        return mosse;
    }

    @Override
    public void eseguiMossa(int scelta, Guerriero avversario) {
        switch (scelta) {
            case 0:
                System.out.println(nome + " scocca una freccia che colpisce " + avversario.getNome() + " con precisione!");
                avversario.subisciDanno(danno);
                consumoEnergia(10);
                break;
            case 1:
                System.out.println(nome + " scocca una freccia avvelenata, infliggendo danni a " + avversario.getNome() + " che continuano nel tempo.");
                avversario.subisciDanno(danno);
                avversario.subisciDanno(5); // Danno extra per veleno
                consumoEnergia(15);
                break;
            case 2:
                System.out.println(nome + " prende la mira e colpisce con un colpo mirato, ferendo gravemente " + avversario.getNome() + "!");
                avversario.subisciDanno(danno * 2);
                consumoEnergia(20);
                break;
            case 3:
                System.out.println(nome + " si concentra per recuperare energia.");
                recuperaEnergia(15);
                break;
            default:
                System.out.println("Mossa non valida!");
        }
    }
}